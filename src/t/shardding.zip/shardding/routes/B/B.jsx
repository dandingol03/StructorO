import React from 'react';
import {render} from 'react-dom';

var B=React.createClass({
    render:function(){
        return (
            <div>
                B
            </div>
        )
    }

});
module.exports=B;