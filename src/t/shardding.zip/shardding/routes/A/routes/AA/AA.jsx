import React from 'react';
import {render} from 'react-dom';

var AA=React.createClass({

    render:function(){
        return (
            <div>
                hi,i am the component AA
            </div>
        )
    }

});
module.exports=AA;