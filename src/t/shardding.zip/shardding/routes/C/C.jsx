import React from 'react';
import {render} from 'react-dom';

var C=React.createClass({
    render:function(){
        return (
            <div>
                C
            </div>
        )
    }
});
module.exports=C;